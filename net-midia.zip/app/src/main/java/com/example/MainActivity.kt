package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainTab
import com.example.ui.MainViewModel
import com.example.ui.SubScreen
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppTopBar
import com.example.ui.modals.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val mainViewModel: MainViewModel = viewModel()

            val currentTab by mainViewModel.currentTab.collectAsStateWithLifecycle()
            val currentSubScreen by mainViewModel.currentSubScreen.collectAsStateWithLifecycle()
            val language by mainViewModel.language.collectAsStateWithLifecycle()
            val isDarkMode by mainViewModel.isDarkMode.collectAsStateWithLifecycle()

            val currentUser by mainViewModel.repository.currentUser.collectAsStateWithLifecycle()
            val posts by mainViewModel.repository.posts.collectAsStateWithLifecycle()
            val stories by mainViewModel.repository.stories.collectAsStateWithLifecycle()
            val reels by mainViewModel.repository.reels.collectAsStateWithLifecycle()
            val chatThreads by mainViewModel.repository.chatThreads.collectAsStateWithLifecycle()
            val friendRequests by mainViewModel.repository.friendRequests.collectAsStateWithLifecycle()
            val users by mainViewModel.repository.users.collectAsStateWithLifecycle()
            val products by mainViewModel.repository.products.collectAsStateWithLifecycle()
            val groups by mainViewModel.repository.groups.collectAsStateWithLifecycle()
            val pages by mainViewModel.repository.pages.collectAsStateWithLifecycle()
            val events by mainViewModel.repository.events.collectAsStateWithLifecycle()
            val notifications by mainViewModel.repository.notifications.collectAsStateWithLifecycle()
            val adminStats by mainViewModel.repository.adminStats.collectAsStateWithLifecycle()
            val siteSettings by mainViewModel.repository.siteSettings.collectAsStateWithLifecycle()

            val activeChatThreadId by mainViewModel.activeChatThreadId.collectAsStateWithLifecycle()
            val activeStory by mainViewModel.activeStory.collectAsStateWithLifecycle()
            val activeCall by mainViewModel.activeCall.collectAsStateWithLifecycle()
            val showAuthModal by mainViewModel.showAuthModal.collectAsStateWithLifecycle()

            val snackbarHostState = remember { SnackbarHostState() }

            // Handle system back press
            BackHandler(
                enabled = currentSubScreen != SubScreen.NONE || activeChatThreadId != null || activeCall != null || activeStory != null || currentTab != MainTab.FEED
            ) {
                mainViewModel.navigateBack()
            }

            MyApplicationTheme(darkTheme = isDarkMode) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        if (currentSubScreen == SubScreen.NONE && activeChatThreadId == null && activeCall == null && currentTab != MainTab.REELS) {
                            AppTopBar(
                                appName = siteSettings["appName"] ?: "NET MIDIA",
                                logoUrl = siteSettings["logoUrl"] ?: "https://files.catbox.moe/kf0sfa.jpg",
                                language = language,
                                isDarkMode = isDarkMode,
                                unreadMessages = chatThreads.sumOf { it.unreadCount },
                                unreadNotifications = notifications.count { !it.isRead },
                                onSearchClick = { mainViewModel.navigateTo(SubScreen.SEARCH) },
                                onMessengerClick = { mainViewModel.selectTab(MainTab.MESSENGER) },
                                onNotificationsClick = { mainViewModel.navigateTo(SubScreen.NOTIFICATIONS) },
                                onLanguageToggle = { mainViewModel.toggleLanguage() },
                                onThemeToggle = { mainViewModel.toggleTheme() },
                                onLogoClick = { mainViewModel.selectTab(MainTab.FEED) }
                            )
                        }
                    },
                    bottomBar = {
                        if (currentSubScreen == SubScreen.NONE && activeChatThreadId == null && activeCall == null) {
                            AppBottomNav(
                                currentTab = currentTab,
                                language = language,
                                onTabSelected = { tab -> mainViewModel.selectTab(tab) }
                            )
                        }
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // SubScreens
                        when (currentSubScreen) {
                            SubScreen.SEARCH -> {
                                SearchScreen(
                                    initialQuery = "",
                                    users = users,
                                    posts = posts,
                                    products = products,
                                    groups = groups,
                                    language = language,
                                    onBack = { mainViewModel.navigateBack() }
                                )
                            }
                            SubScreen.NOTIFICATIONS -> {
                                NotificationsScreen(
                                    notifications = notifications,
                                    language = language,
                                    onBack = { mainViewModel.navigateBack() }
                                )
                            }
                            SubScreen.PROFILE -> {
                                ProfileScreen(
                                    user = currentUser,
                                    userPosts = posts.filter { it.author.id == currentUser.id },
                                    language = language,
                                    onBack = { mainViewModel.navigateBack() },
                                    onUpdateProfile = { name, bio, phone, email ->
                                        mainViewModel.repository.updateProfile(name, bio, phone, email)
                                    }
                                )
                            }
                            SubScreen.MARKETPLACE -> {
                                MarketplaceScreen(
                                    products = products,
                                    language = language,
                                    onBack = { mainViewModel.navigateBack() },
                                    onProductClick = { product ->
                                        mainViewModel.selectTab(MainTab.MESSENGER)
                                    },
                                    onAddProduct = { title, price, cat, loc, desc ->
                                        mainViewModel.repository.addProduct(title, price, cat, loc, desc, "")
                                    }
                                )
                            }
                            SubScreen.GROUPS -> {
                                GroupsPagesScreen(
                                    groups = groups,
                                    pages = pages,
                                    language = language,
                                    onBack = { mainViewModel.navigateBack() },
                                    onToggleJoinGroup = { id -> mainViewModel.repository.toggleGroupJoin(id) },
                                    onToggleFollowPage = { id -> mainViewModel.repository.togglePageFollow(id) }
                                )
                            }
                            SubScreen.PAGES -> {
                                GroupsPagesScreen(
                                    groups = groups,
                                    pages = pages,
                                    language = language,
                                    onBack = { mainViewModel.navigateBack() },
                                    onToggleJoinGroup = { id -> mainViewModel.repository.toggleGroupJoin(id) },
                                    onToggleFollowPage = { id -> mainViewModel.repository.togglePageFollow(id) }
                                )
                            }
                            SubScreen.EVENTS -> {
                                EventsScreen(
                                    events = events,
                                    language = language,
                                    onBack = { mainViewModel.navigateBack() },
                                    onToggleGoing = { id -> mainViewModel.repository.toggleEventGoing(id) }
                                )
                            }
                            SubScreen.ADMIN -> {
                                AdminScreen(
                                    stats = adminStats,
                                    users = users,
                                    siteSettings = siteSettings,
                                    language = language,
                                    onBack = { mainViewModel.navigateBack() },
                                    onToggleBlockUser = { id -> mainViewModel.repository.toggleBlockUser(id) },
                                    onToggleVerifyUser = { id -> mainViewModel.repository.toggleVerifyUser(id) },
                                    onUpdateSiteSetting = { key, value -> mainViewModel.repository.updateSiteSetting(key, value) }
                                )
                            }
                            SubScreen.LIVE_STREAM -> {
                                LiveStreamScreen(
                                    currentUser = currentUser,
                                    language = language,
                                    onClose = { mainViewModel.navigateBack() }
                                )
                            }
                            SubScreen.SETTINGS -> {
                                SettingsScreen(
                                    language = language,
                                    isDarkMode = isDarkMode,
                                    onBack = { mainViewModel.navigateBack() },
                                    onToggleLanguage = { mainViewModel.toggleLanguage() },
                                    onToggleTheme = { mainViewModel.toggleTheme() },
                                    onLogout = { mainViewModel.setLoggedIn(false) }
                                )
                            }
                            SubScreen.NONE, SubScreen.CREATE_POST, SubScreen.CREATE_STORY, SubScreen.STORY_VIEW -> {
                                // Main Tabs
                                when (currentTab) {
                                    MainTab.FEED -> {
                                        FeedScreen(
                                            currentUser = currentUser,
                                            stories = stories,
                                            posts = posts,
                                            language = language,
                                            onCreatePostClick = { mainViewModel.navigateTo(SubScreen.CREATE_POST) },
                                            onCreateStoryClick = { mainViewModel.navigateTo(SubScreen.CREATE_STORY) },
                                            onStoryClick = { story -> mainViewModel.openStory(story) },
                                            onReactionSelect = { postId, reaction -> mainViewModel.repository.toggleReaction(postId, reaction) },
                                            onCommentClick = { postId -> },
                                            onShareClick = { postId -> },
                                            onSaveClick = { postId -> mainViewModel.repository.toggleSavePost(postId) },
                                            onDeleteClick = { postId -> mainViewModel.repository.deletePost(postId) },
                                            onPollVote = { postId, optId -> mainViewModel.repository.votePoll(postId, optId) },
                                            onLiveClick = { mainViewModel.navigateTo(SubScreen.LIVE_STREAM) }
                                        )
                                    }
                                    MainTab.REELS -> {
                                        ReelsScreen(
                                            reels = reels,
                                            language = language,
                                            onLikeClick = { id -> mainViewModel.repository.toggleReelLike(id) },
                                            onFollowClick = { id -> mainViewModel.repository.toggleReelFollow(id) },
                                            onShareClick = { }
                                        )
                                    }
                                    MainTab.MESSENGER -> {
                                        MessengerScreen(
                                            currentUserId = currentUser.id,
                                            threads = chatThreads,
                                            onlineUsers = users,
                                            activeThreadId = activeChatThreadId,
                                            language = language,
                                            onThreadClick = { id -> mainViewModel.openChatThread(id) },
                                            onBackToThreads = { mainViewModel.closeChatThread() },
                                            onSendMessage = { threadId, text -> mainViewModel.repository.sendMessage(threadId, text) },
                                            onVoiceCallClick = { user -> mainViewModel.startCall(user, isVideo = false) },
                                            onVideoCallClick = { user -> mainViewModel.startCall(user, isVideo = true) }
                                        )
                                    }
                                    MainTab.FRIENDS -> {
                                        FriendsScreen(
                                            friendRequests = friendRequests,
                                            suggestions = users.filter { it.id != currentUser.id },
                                            language = language,
                                            onAcceptRequest = { id -> mainViewModel.repository.acceptFriendRequest(id) },
                                            onRejectRequest = { id -> mainViewModel.repository.rejectFriendRequest(id) },
                                            onAddFriend = { }
                                        )
                                    }
                                    MainTab.MENU -> {
                                        MenuHubScreen(
                                            currentUser = currentUser,
                                            language = language,
                                            onNavigate = { screen -> mainViewModel.navigateTo(screen) },
                                            onLogout = { mainViewModel.setLoggedIn(false) }
                                        )
                                    }
                                }
                            }
                        }

                        // Modals & Overlays
                        if (currentSubScreen == SubScreen.CREATE_POST) {
                            CreatePostModal(
                                currentUser = currentUser,
                                language = language,
                                onDismiss = { mainViewModel.navigateBack() },
                                onSubmitPost = { content, mediaUrls, feeling, location, poll ->
                                    mainViewModel.repository.addPost(content, mediaUrls, feeling, location, poll)
                                }
                            )
                        }

                        if (currentSubScreen == SubScreen.CREATE_STORY) {
                            CreateStoryModal(
                                language = language,
                                onDismiss = { mainViewModel.navigateBack() },
                                onSubmitStory = { text, media, bgHex ->
                                    mainViewModel.repository.addStory(text, media, bgHex)
                                }
                            )
                        }

                        activeStory?.let { story ->
                            StoryViewerModal(
                                story = story,
                                language = language,
                                onClose = { mainViewModel.closeStory() },
                                onReply = { }
                            )
                        }

                        activeCall?.let { call ->
                            CallModal(
                                call = call,
                                language = language,
                                onAnswer = { mainViewModel.answerCall() },
                                onToggleMute = { mainViewModel.toggleMuteCall() },
                                onEndCall = { mainViewModel.endCall() }
                            )
                        }

                        if (showAuthModal) {
                            AuthModal(
                                language = language,
                                onSuccessLogin = { mainViewModel.setLoggedIn(true) },
                                onDismiss = { mainViewModel.setShowAuthModal(false) }
                            )
                        }
                    }
                }
            }
        }
    }
}
