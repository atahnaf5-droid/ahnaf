package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.AppLanguage
import com.example.localization.Strings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    language: AppLanguage,
    isDarkMode: Boolean,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit,
    onToggleTheme: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    var twoFactorEnabled by remember { mutableStateOf(true) }
    var dataSaverEnabled by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(Strings.get("settings", language), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .testTag("settings_screen"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Preferences Section
            item {
                Text("Preferences", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }

            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        SettingItemRow(
                            icon = Icons.Default.Language,
                            title = Strings.get("language", language),
                            subtitle = if (language == AppLanguage.BANGLA) "বাংলা" else "English",
                            onClick = onToggleLanguage
                        )
                        Divider(modifier = Modifier.padding(horizontal = 16.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(14.dp))
                                Text(Strings.get("dark_mode", language), fontWeight = FontWeight.Medium)
                            }
                            Switch(checked = isDarkMode, onCheckedChange = { onToggleTheme() })
                        }
                    }
                }
            }

            // Security & Privacy Section
            item {
                Text("Security & Privacy", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }

            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text("Two-Factor Authentication (2FA)", fontWeight = FontWeight.Medium)
                                    Text("Require OTP code at login", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Switch(checked = twoFactorEnabled, onCheckedChange = { twoFactorEnabled = it })
                        }
                        Divider(modifier = Modifier.padding(horizontal = 16.dp))
                        SettingItemRow(
                            icon = Icons.Default.Devices,
                            title = "Active Sessions",
                            subtitle = "Android 14 (Pixel 8) • Chrome Web",
                            onClick = { }
                        )
                        Divider(modifier = Modifier.padding(horizontal = 16.dp))
                        SettingItemRow(
                            icon = Icons.Default.Lock,
                            title = "Privacy Controls",
                            subtitle = "Posts, Stories & Profile Visibility",
                            onClick = { }
                        )
                        Divider(modifier = Modifier.padding(horizontal = 16.dp))
                        SettingItemRow(
                            icon = Icons.Default.Block,
                            title = "Blocked Users",
                            subtitle = "Manage blocked accounts",
                            onClick = { }
                        )
                    }
                }
            }

            // Support & Legal
            item {
                Text("Support & Legal", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }

            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        SettingItemRow(icon = Icons.Default.Help, title = "Help & Support Center", subtitle = "FAQs, Contact Us", onClick = { })
                        Divider(modifier = Modifier.padding(horizontal = 16.dp))
                        SettingItemRow(icon = Icons.Default.Description, title = "Terms of Service", subtitle = "User Agreement & Rules", onClick = { })
                        Divider(modifier = Modifier.padding(horizontal = 16.dp))
                        SettingItemRow(icon = Icons.Default.PrivacyTip, title = "Privacy Policy", subtitle = "Data & Community Safety", onClick = { })
                    }
                }
            }

            item {
                Button(
                    onClick = onLogout,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(Strings.get("logout", language), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SettingItemRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
