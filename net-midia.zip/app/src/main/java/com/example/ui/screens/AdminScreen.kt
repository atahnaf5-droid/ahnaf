package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.model.AdminStats
import com.example.model.User
import com.example.ui.theme.NetPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    stats: AdminStats,
    users: List<User>,
    siteSettings: Map<String, String>,
    language: AppLanguage,
    onBack: () -> Unit,
    onToggleBlockUser: (String) -> Unit,
    onToggleVerifyUser: (String) -> Unit,
    onUpdateSiteSetting: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var adminTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredUsers = if (searchQuery.isBlank()) users else users.filter {
        it.name.contains(searchQuery, ignoreCase = true) || it.username.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(Strings.get("admin_panel", language), fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("admin_screen")
        ) {
            TabRow(
                selectedTabIndex = adminTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Tab(
                    selected = adminTab == 0,
                    onClick = { adminTab = 0 },
                    text = { Text("Dashboard", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = adminTab == 1,
                    onClick = { adminTab = 1 },
                    text = { Text(Strings.get("user_management", language), fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = adminTab == 2,
                    onClick = { adminTab = 2 },
                    text = { Text(Strings.get("site_settings", language), fontWeight = FontWeight.Bold) }
                )
            }

            when (adminTab) {
                0 -> {
                    // Statistics Dashboard
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "Platform Overview & Real-time Metrics",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatCard("Total Users", "${"%,d".format(stats.totalUsers)}", Color(0xFF2563EB), Modifier.weight(1f))
                                StatCard("Active Users", "${"%,d".format(stats.activeUsers)}", Color(0xFF10B981), Modifier.weight(1f))
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatCard("Total Posts", "${"%,d".format(stats.totalPosts)}", Color(0xFF8B5CF6), Modifier.weight(1f))
                                StatCard("Total Reels", "${"%,d".format(stats.totalReels)}", Color(0xFFEC4899), Modifier.weight(1f))
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatCard("Total Messages", "${"%,d".format(stats.totalMessages)}", Color(0xFF06B6D4), Modifier.weight(1f))
                                StatCard("Total Comments", "${"%,d".format(stats.totalComments)}", Color(0xFFF59E0B), Modifier.weight(1f))
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatCard("Total Groups", "${stats.totalGroups}", Color(0xFF14B8A6), Modifier.weight(1f))
                                StatCard("Pending Reports", "${stats.totalReports}", Color(0xFFEF4444), Modifier.weight(1f))
                            }
                        }
                    }
                }
                1 -> {
                    // User Management
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search users by name or @username...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredUsers, key = { it.id }) { u ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        AsyncImage(
                                            model = u.avatarUrl,
                                            contentDescription = u.name,
                                            modifier = Modifier
                                                .size(46.dp)
                                                .clip(CircleShape),
                                            contentScale = ContentScale.Crop
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(u.name, fontWeight = FontWeight.Bold)
                                                if (u.isVerified) {
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Icon(Icons.Default.CheckCircle, contentDescription = "Verified", tint = NetPrimary, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                            Text("@${u.username} • Role: ${u.role}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }

                                        // Action buttons: Verify, Block
                                        IconButton(onClick = { onToggleVerifyUser(u.id) }) {
                                            Icon(
                                                imageVector = Icons.Default.Verified,
                                                contentDescription = "Toggle Verify",
                                                tint = if (u.isVerified) NetPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(onClick = { onToggleBlockUser(u.id) }) {
                                            Icon(
                                                imageVector = Icons.Default.Block,
                                                contentDescription = "Toggle Block",
                                                tint = if (u.isBlocked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Site Settings
                    var appName by remember { mutableStateOf(siteSettings["appName"] ?: "NET MIDIA") }
                    var logoUrl by remember { mutableStateOf(siteSettings["logoUrl"] ?: "https://files.catbox.moe/kf0sfa.jpg") }
                    var maintenance by remember { mutableStateOf((siteSettings["maintenanceMode"] ?: "false") == "true") }
                    var announcement by remember { mutableStateOf(siteSettings["activeAnnouncement"] ?: "") }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Text("Brand & Application Settings", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }

                        item {
                            OutlinedTextField(
                                value = appName,
                                onValueChange = {
                                    appName = it
                                    onUpdateSiteSetting("appName", it)
                                },
                                label = { Text("App Name") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            OutlinedTextField(
                                value = logoUrl,
                                onValueChange = {
                                    logoUrl = it
                                    onUpdateSiteSetting("logoUrl", it)
                                },
                                label = { Text("Logo URL") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            OutlinedTextField(
                                value = announcement,
                                onValueChange = {
                                    announcement = it
                                    onUpdateSiteSetting("activeAnnouncement", it)
                                },
                                label = { Text("Active System Announcement") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(Strings.get("maintenance_mode", language), fontWeight = FontWeight.Bold)
                                        Text("Restrict general access for maintenance", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Switch(
                                        checked = maintenance,
                                        onCheckedChange = {
                                            maintenance = it
                                            onUpdateSiteSetting("maintenanceMode", it.toString())
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, color = color)
            )
        }
    }
}
