package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NetPrimary = Color(0xFF2563EB) // Vibrant Social Blue
val NetPrimaryDark = Color(0xFF3B82F6)
val NetSecondary = Color(0xFF06B6D4) // Modern Cyan
val NetTertiary = Color(0xFFF43F5E) // Radiant Coral

val NetBackgroundLight = Color(0xFFF8FAFC)
val NetSurfaceLight = Color(0xFFFFFFFF)
val NetSurfaceVariantLight = Color(0xFFF1F5F9)
val NetTextPrimaryLight = Color(0xFF0F172A)
val NetTextSecondaryLight = Color(0xFF64748B)

val NetBackgroundDark = Color(0xFF0B0F19)
val NetSurfaceDark = Color(0xFF131B2E)
val NetSurfaceVariantDark = Color(0xFF1E293B)
val NetTextPrimaryDark = Color(0xFFF8FAFC)
val NetTextSecondaryDark = Color(0xFF94A3B8)

// Reaction Colors
val ReactionLikeColor = Color(0xFF1877F2)
val ReactionLoveColor = Color(0xFFFA3E3E)
val ReactionHahaColor = Color(0xFFF7B125)
val ReactionWowColor = Color(0xFFF7B125)
val ReactionSadColor = Color(0xFFF7B125)
val ReactionAngryColor = Color(0xFFE04006)
