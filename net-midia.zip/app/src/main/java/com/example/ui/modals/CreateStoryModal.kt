package com.example.ui.modals

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.theme.NetPrimary

@Composable
fun CreateStoryModal(
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSubmitStory: (String?, String?, Long) -> Unit
) {
    val bgColors = listOf(
        0xFF4F46E5, // Indigo
        0xFFEC4899, // Pink
        0xFF10B981, // Emerald
        0xFFF59E0B, // Amber
        0xFF8B5CF6, // Purple
        0xFF0F172A  // Slate
    )
    var selectedColor by remember { mutableStateOf(bgColors.first()) }
    var storyText by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(selectedColor))
            .testTag("create_story_screen")
    ) {
        // Top Controls: Close & Share
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .size(40.dp)
                    .background(Color.Black.copy(alpha = 0.4f), CircleShape)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }

            Button(
                onClick = {
                    if (storyText.isNotBlank()) {
                        onSubmitStory(storyText, null, selectedColor)
                        onDismiss()
                    }
                },
                enabled = storyText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp)
            ) {
                Text("Share to Story", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }

        // Center Story Text Field
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp)
                .align(Alignment.Center),
            contentAlignment = Alignment.Center
        ) {
            OutlinedTextField(
                value = storyText,
                onValueChange = { storyText = it },
                placeholder = {
                    Text(
                        "Start typing your story...",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent
                ),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
        }

        // Bottom Color Picker Palette
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Select Story Background", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(bgColors) { colorHex ->
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(colorHex))
                            .border(
                                width = if (selectedColor == colorHex) 3.dp else 1.dp,
                                color = if (selectedColor == colorHex) Color.White else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { selectedColor = colorHex }
                    )
                }
            }
        }
    }
}
