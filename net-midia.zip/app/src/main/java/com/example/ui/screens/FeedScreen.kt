package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.model.Post
import com.example.model.ReactionType
import com.example.model.Story
import com.example.model.User
import com.example.ui.components.PostCard
import com.example.ui.components.StoryTray

@Composable
fun FeedScreen(
    currentUser: User,
    stories: List<Story>,
    posts: List<Post>,
    language: AppLanguage,
    onCreatePostClick: () -> Unit,
    onCreateStoryClick: () -> Unit,
    onStoryClick: (Story) -> Unit,
    onReactionSelect: (String, ReactionType) -> Unit,
    onCommentClick: (String) -> Unit,
    onShareClick: (String) -> Unit,
    onSaveClick: (String) -> Unit,
    onDeleteClick: (String) -> Unit,
    onPollVote: (String, String) -> Unit,
    onLiveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("feed_screen_list"),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Stories Tray
        item {
            StoryTray(
                currentUser = currentUser,
                stories = stories,
                language = language,
                onCreateStoryClick = onCreateStoryClick,
                onStoryClick = onStoryClick,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        // 2. Create Post Trigger Widget
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .testTag("create_post_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        AsyncImage(
                            model = currentUser.avatarUrl,
                            contentDescription = "My avatar",
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable(onClick = onCreatePostClick)
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .testTag("whats_on_your_mind_button")
                        ) {
                            Text(
                                text = Strings.get("whats_on_your_mind", language),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.8.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Shortcuts: Live, Photo, Feeling
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onLiveClick)
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("shortcut_live_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "Live",
                                tint = Color(0xFFEF4444),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = Strings.get("live", language),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onCreatePostClick)
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("shortcut_photo_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = "Photo",
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = Strings.get("photo_video", language),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onCreatePostClick)
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("shortcut_feeling_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mood,
                                contentDescription = "Feeling",
                                tint = Color(0xFFF59E0B),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = Strings.get("feeling_activity", language),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }
                }
            }
        }

        // 3. Posts List
        items(posts, key = { it.id }) { post ->
            PostCard(
                post = post,
                currentUserId = currentUser.id,
                language = language,
                onReactionSelect = { reaction -> onReactionSelect(post.id, reaction) },
                onCommentClick = { onCommentClick(post.id) },
                onShareClick = { onShareClick(post.id) },
                onSaveClick = { onSaveClick(post.id) },
                onDeleteClick = { onDeleteClick(post.id) },
                onPollVote = { optionId -> onPollVote(post.id, optionId) },
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }
    }
}
