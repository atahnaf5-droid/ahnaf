package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = NetPrimaryDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = NetSecondary,
    onSecondary = Color.Black,
    tertiary = NetTertiary,
    background = NetBackgroundDark,
    surface = NetSurfaceDark,
    surfaceVariant = NetSurfaceVariantDark,
    onBackground = NetTextPrimaryDark,
    onSurface = NetTextPrimaryDark,
    onSurfaceVariant = NetTextSecondaryDark
)

private val LightColorScheme = lightColorScheme(
    primary = NetPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = NetSecondary,
    onSecondary = Color.White,
    tertiary = NetTertiary,
    background = NetBackgroundLight,
    surface = NetSurfaceLight,
    surfaceVariant = NetSurfaceVariantLight,
    onBackground = NetTextPrimaryLight,
    onSurface = NetTextPrimaryLight,
    onSurfaceVariant = NetTextSecondaryLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
