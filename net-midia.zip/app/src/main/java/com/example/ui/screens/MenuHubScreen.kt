package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.model.User
import com.example.model.UserRole
import com.example.ui.SubScreen
import com.example.ui.theme.NetPrimary
import com.example.ui.theme.NetSecondary

data class MenuItemData(
    val title: String,
    val icon: ImageVector,
    val iconTint: Color,
    val screen: SubScreen
)

@Composable
fun MenuHubScreen(
    currentUser: User,
    language: AppLanguage,
    onNavigate: (SubScreen) -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val menuItems = listOf(
        MenuItemData(Strings.get("marketplace", language), Icons.Default.Storefront, Color(0xFF3B82F6), SubScreen.MARKETPLACE),
        MenuItemData(Strings.get("groups", language), Icons.Default.Groups, Color(0xFF10B981), SubScreen.GROUPS),
        MenuItemData(Strings.get("pages", language), Icons.Default.Flag, Color(0xFFF59E0B), SubScreen.PAGES),
        MenuItemData(Strings.get("events", language), Icons.Default.Event, Color(0xFFEC4899), SubScreen.EVENTS),
        MenuItemData(Strings.get("live", language), Icons.Default.Videocam, Color(0xFFEF4444), SubScreen.LIVE_STREAM),
        MenuItemData(Strings.get("gaming", language), Icons.Default.SportsEsports, Color(0xFF8B5CF6), SubScreen.NONE),
        MenuItemData(Strings.get("settings", language), Icons.Default.Settings, Color(0xFF64748B), SubScreen.SETTINGS),
        MenuItemData(Strings.get("admin_panel", language), Icons.Default.AdminPanelSettings, Color(0xFFD97706), SubScreen.ADMIN)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("menu_hub_screen")
    ) {
        // User Profile Card Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigate(SubScreen.PROFILE) }
                .testTag("menu_profile_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = currentUser.avatarUrl,
                    contentDescription = currentUser.name,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentUser.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "View your profile",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Open Profile",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "All Shortcuts",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 10.dp)
        )

        // Shortcuts Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(menuItems.size) { index ->
                val item = menuItems[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(86.dp)
                        .clickable {
                            if (item.screen != SubScreen.NONE) {
                                onNavigate(item.screen)
                            }
                        }
                        .testTag("shortcut_${item.title.lowercase().replace(" ", "_")}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = item.iconTint,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Logout Button
        OutlinedButton(
            onClick = onLogout,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("logout_button"),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
        ) {
            Icon(
                imageVector = Icons.Default.Logout,
                contentDescription = Strings.get("logout", language),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = Strings.get("logout", language), fontWeight = FontWeight.Bold)
        }
    }
}
