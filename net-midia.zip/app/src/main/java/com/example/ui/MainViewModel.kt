package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DataRepository
import com.example.localization.AppLanguage
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class MainTab {
    FEED, REELS, MESSENGER, FRIENDS, MENU
}

enum class SubScreen {
    NONE,
    SEARCH,
    NOTIFICATIONS,
    PROFILE,
    MARKETPLACE,
    GROUPS,
    PAGES,
    EVENTS,
    ADMIN,
    LIVE_STREAM,
    CREATE_POST,
    CREATE_STORY,
    STORY_VIEW,
    SETTINGS
}

data class ActiveCall(
    val user: User,
    val isVideo: Boolean,
    val isConnected: Boolean = false,
    val durationSec: Int = 0,
    val isMuted: Boolean = false
)

class MainViewModel(
    val repository: DataRepository = DataRepository()
) : ViewModel() {

    private val _currentTab = MutableStateFlow(MainTab.FEED)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _currentSubScreen = MutableStateFlow(SubScreen.NONE)
    val currentSubScreen: StateFlow<SubScreen> = _currentSubScreen.asStateFlow()

    private val _subScreenStack = MutableStateFlow<List<SubScreen>>(emptyList())

    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _activeChatThreadId = MutableStateFlow<String?>(null)
    val activeChatThreadId: StateFlow<String?> = _activeChatThreadId.asStateFlow()

    private val _activeStory = MutableStateFlow<Story?>(null)
    val activeStory: StateFlow<Story?> = _activeStory.asStateFlow()

    private val _activeCall = MutableStateFlow<ActiveCall?>(null)
    val activeCall: StateFlow<ActiveCall?> = _activeCall.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(true)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _showAuthModal = MutableStateFlow(false)
    val showAuthModal: StateFlow<Boolean> = _showAuthModal.asStateFlow()

    private val _messageToast = MutableStateFlow<String?>(null)
    val messageToast: StateFlow<String?> = _messageToast.asStateFlow()

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
        _currentSubScreen.value = SubScreen.NONE
        _activeChatThreadId.value = null
    }

    fun navigateTo(screen: SubScreen) {
        _currentSubScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (_activeCall.value != null) {
            _activeCall.value = null
            return true
        }
        if (_activeChatThreadId.value != null) {
            _activeChatThreadId.value = null
            return true
        }
        if (_activeStory.value != null) {
            _activeStory.value = null
            return true
        }
        if (_currentSubScreen.value != SubScreen.NONE) {
            _currentSubScreen.value = SubScreen.NONE
            return true
        }
        if (_currentTab.value != MainTab.FEED) {
            _currentTab.value = MainTab.FEED
            return true
        }
        return false
    }

    fun toggleLanguage() {
        _language.value = if (_language.value == AppLanguage.ENGLISH) AppLanguage.BANGLA else AppLanguage.ENGLISH
    }

    fun toggleTheme() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun openChatThread(threadId: String) {
        _activeChatThreadId.value = threadId
    }

    fun closeChatThread() {
        _activeChatThreadId.value = null
    }

    fun openStory(story: Story) {
        _activeStory.value = story
        _currentSubScreen.value = SubScreen.STORY_VIEW
    }

    fun closeStory() {
        _activeStory.value = null
        _currentSubScreen.value = SubScreen.NONE
    }

    fun startCall(user: User, isVideo: Boolean) {
        _activeCall.value = ActiveCall(user = user, isVideo = isVideo, isConnected = false)
    }

    fun answerCall() {
        _activeCall.value = _activeCall.value?.copy(isConnected = true)
    }

    fun toggleMuteCall() {
        _activeCall.value = _activeCall.value?.let { it.copy(isMuted = !it.isMuted) }
    }

    fun endCall() {
        _activeCall.value = null
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun showToast(msg: String) {
        _messageToast.value = msg
    }

    fun clearToast() {
        _messageToast.value = null
    }

    fun setLoggedIn(loggedIn: Boolean) {
        _isLoggedIn.value = loggedIn
        if (!loggedIn) {
            _showAuthModal.value = true
        }
    }

    fun setShowAuthModal(show: Boolean) {
        _showAuthModal.value = show
    }
}
