package com.example.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.MainTab

@Composable
fun AppBottomNav(
    currentTab: MainTab,
    language: AppLanguage,
    onTabSelected: (MainTab) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier.testTag("bottom_navigation_bar")
    ) {
        NavigationBarItem(
            selected = currentTab == MainTab.FEED,
            onClick = { onTabSelected(MainTab.FEED) },
            icon = {
                Icon(
                    imageVector = if (currentTab == MainTab.FEED) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = Strings.get("home", language),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = { Text(Strings.get("home", language)) },
            modifier = Modifier.testTag("nav_tab_home")
        )

        NavigationBarItem(
            selected = currentTab == MainTab.REELS,
            onClick = { onTabSelected(MainTab.REELS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == MainTab.REELS) Icons.Filled.PlayCircle else Icons.Outlined.PlayCircleOutline,
                    contentDescription = Strings.get("reels", language),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = { Text(Strings.get("reels", language)) },
            modifier = Modifier.testTag("nav_tab_reels")
        )

        NavigationBarItem(
            selected = currentTab == MainTab.MESSENGER,
            onClick = { onTabSelected(MainTab.MESSENGER) },
            icon = {
                Icon(
                    imageVector = if (currentTab == MainTab.MESSENGER) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                    contentDescription = Strings.get("messages", language),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = { Text(Strings.get("messages", language)) },
            modifier = Modifier.testTag("nav_tab_messenger")
        )

        NavigationBarItem(
            selected = currentTab == MainTab.FRIENDS,
            onClick = { onTabSelected(MainTab.FRIENDS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == MainTab.FRIENDS) Icons.Filled.People else Icons.Outlined.PeopleOutline,
                    contentDescription = Strings.get("friends", language),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = { Text(Strings.get("friends", language)) },
            modifier = Modifier.testTag("nav_tab_friends")
        )

        NavigationBarItem(
            selected = currentTab == MainTab.MENU,
            onClick = { onTabSelected(MainTab.MENU) },
            icon = {
                Icon(
                    imageVector = if (currentTab == MainTab.MENU) Icons.Filled.Menu else Icons.Outlined.Menu,
                    contentDescription = Strings.get("menu", language),
                    modifier = Modifier.size(24.dp)
                )
            },
            label = { Text(Strings.get("menu", language)) },
            modifier = Modifier.testTag("nav_tab_menu")
        )
    }
}
