package com.example.ui.modals

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.model.PollData
import com.example.model.PollOption
import com.example.model.User
import com.example.ui.theme.NetPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostModal(
    currentUser: User,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSubmitPost: (String, List<String>, String?, String?, PollData?) -> Unit
) {
    var contentText by remember { mutableStateOf("") }
    var selectedFeeling by remember { mutableStateOf<String?>(null) }
    var locationText by remember { mutableStateOf<String?>(null) }
    var attachedImages by remember { mutableStateOf<List<String>>(emptyList()) }
    var showPollBuilder by remember { mutableStateOf(false) }
    var pollQuestion by remember { mutableStateOf("") }
    var pollOpt1 by remember { mutableStateOf("") }
    var pollOpt2 by remember { mutableStateOf("") }

    val feelings = listOf("blessed ✨", "excited 🎉", "happy 😊", "traveling ✈️", "productive 💻")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        modifier = Modifier.testTag("create_post_modal")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = Strings.get("create_post", language),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Button(
                    onClick = {
                        val poll = if (showPollBuilder && pollQuestion.isNotBlank()) {
                            PollData(
                                question = pollQuestion,
                                options = listOf(
                                    PollOption("opt_1", pollOpt1.ifBlank { "Option 1" }, 0),
                                    PollOption("opt_2", pollOpt2.ifBlank { "Option 2" }, 0)
                                )
                            )
                        } else null

                        onSubmitPost(contentText, attachedImages, selectedFeeling, locationText, poll)
                        onDismiss()
                    },
                    enabled = contentText.isNotBlank() || attachedImages.isNotEmpty() || showPollBuilder,
                    colors = ButtonDefaults.buttonColors(containerColor = NetPrimary),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("submit_post_button")
                ) {
                    Text(Strings.get("post", language), fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Author info & Privacy chip
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = currentUser.avatarUrl,
                    contentDescription = currentUser.name,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(currentUser.name, fontWeight = FontWeight.Bold)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Public", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            if (selectedFeeling != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text("Feeling: $selectedFeeling", style = MaterialTheme.typography.bodySmall, color = NetPrimary)
            }
            if (locationText != null) {
                Text("Location: 📍 $locationText", style = MaterialTheme.typography.bodySmall, color = NetPrimary)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Text Input
            OutlinedTextField(
                value = contentText,
                onValueChange = { contentText = it },
                placeholder = { Text(Strings.get("whats_on_your_mind", language)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp)
                    .testTag("post_content_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent
                )
            )

            // Attached image previews
            if (attachedImages.isNotEmpty()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    items(attachedImages) { url ->
                        AsyncImage(
                            model = url,
                            contentDescription = "Attachment",
                            modifier = Modifier
                                .size(80.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            // Poll Creator if enabled
            if (showPollBuilder) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Create a Poll", fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = pollQuestion,
                            onValueChange = { pollQuestion = it },
                            placeholder = { Text("Ask a question...") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = pollOpt1,
                            onValueChange = { pollOpt1 = it },
                            placeholder = { Text("Option 1") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = pollOpt2,
                            onValueChange = { pollOpt2 = it },
                            placeholder = { Text("Option 2") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            // Add-on tools
            Text("Add to your post", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Add Photo shortcut
                IconButton(
                    onClick = {
                        attachedImages = attachedImages + "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800"
                    }
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = "Add Photo", tint = Color(0xFF10B981))
                }
                // Add Feeling
                IconButton(
                    onClick = {
                        selectedFeeling = feelings.random()
                    }
                ) {
                    Icon(Icons.Default.Mood, contentDescription = "Feeling", tint = Color(0xFFF59E0B))
                }
                // Add Location
                IconButton(
                    onClick = {
                        locationText = "Dhaka, Bangladesh"
                    }
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = Color(0xFFEF4444))
                }
                // Add Poll
                IconButton(
                    onClick = {
                        showPollBuilder = !showPollBuilder
                    }
                ) {
                    Icon(Icons.Default.Poll, contentDescription = "Poll", tint = Color(0xFF2563EB))
                }
                // Tag Friends
                IconButton(onClick = { }) {
                    Icon(Icons.Default.PersonAdd, contentDescription = "Tag", tint = Color(0xFF8B5CF6))
                }
            }
        }
    }
}
