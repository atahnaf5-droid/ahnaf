package com.example.model

enum class ReactionType(val label: String, val emoji: String, val colorHex: Long) {
    LIKE("Like", "👍", 0xFF1877F2),
    LOVE("Love", "❤️", 0xFFFA3E3E),
    HAHA("Haha", "😆", 0xFFF7B125),
    WOW("Wow", "😮", 0xFFF7B125),
    SAD("Sad", "😢", 0xFFF7B125),
    ANGRY("Angry", "😡", 0xFFE04006)
}

enum class UserRole {
    USER, ADMIN
}

data class User(
    val id: String,
    val name: String,
    val username: String,
    val email: String = "",
    val phone: String = "",
    val avatarUrl: String,
    val coverUrl: String = "",
    val bio: String = "",
    val isVerified: Boolean = false,
    val followersCount: Int = 120,
    val followingCount: Int = 85,
    val friendsCount: Int = 240,
    val isOnline: Boolean = false,
    val role: UserRole = UserRole.USER,
    val isBlocked: Boolean = false
)

data class PollOption(
    val id: String,
    val text: String,
    val votes: Int,
    val votedUserIds: List<String> = emptyList()
)

data class PollData(
    val question: String,
    val options: List<PollOption>
)

data class CommentReply(
    val id: String,
    val author: User,
    val text: String,
    val timestamp: String,
    val likes: Int = 0
)

data class Comment(
    val id: String,
    val author: User,
    val text: String,
    val timestamp: String,
    val likes: Int = 0,
    val replies: List<CommentReply> = emptyList()
)

data class Post(
    val id: String,
    val author: User,
    val timestamp: String,
    val content: String,
    val mediaUrls: List<String> = emptyList(),
    val feeling: String? = null,
    val location: String? = null,
    val hashtags: List<String> = emptyList(),
    val poll: PollData? = null,
    val reactions: Map<ReactionType, Int> = emptyMap(),
    val userReaction: ReactionType? = null,
    val comments: List<Comment> = emptyList(),
    val shareCount: Int = 0,
    val isSaved: Boolean = false,
    val privacy: String = "Public"
)

data class Story(
    val id: String,
    val author: User,
    val mediaUrl: String? = null,
    val textContent: String? = null,
    val backgroundHex: Long = 0xFF1E293B,
    val createdAt: String = "2h ago",
    val viewersCount: Int = 14,
    val viewers: List<User> = emptyList()
)

data class Reel(
    val id: String,
    val creator: User,
    val caption: String,
    val videoThumbUrl: String,
    val musicTitle: String,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val isFollowing: Boolean = false
)

data class ChatMessage(
    val id: String,
    val senderId: String,
    val text: String,
    val mediaUrl: String? = null,
    val voiceDurationSec: Int? = null,
    val timestamp: String,
    val isSeen: Boolean = true
)

data class ChatThread(
    val id: String,
    val participant: User,
    val isGroup: Boolean = false,
    val groupName: String? = null,
    val messages: List<ChatMessage> = emptyList(),
    val unreadCount: Int = 0
)

data class FriendRequest(
    val id: String,
    val user: User,
    val mutualFriends: Int,
    val timeAgo: String
)

data class GroupItem(
    val id: String,
    val name: String,
    val category: String,
    val memberCount: Int,
    val coverUrl: String,
    val isJoined: Boolean = false,
    val description: String = "",
    val rules: List<String> = emptyList(),
    val isAdmin: Boolean = false
)

data class PageItem(
    val id: String,
    val name: String,
    val category: String,
    val followersCount: Int,
    val coverUrl: String,
    val avatarUrl: String,
    val isFollowing: Boolean = false,
    val isVerified: Boolean = true,
    val about: String = ""
)

data class ProductItem(
    val id: String,
    val title: String,
    val price: Double,
    val category: String,
    val location: String,
    val seller: User,
    val imageUrl: String,
    val description: String,
    val isSold: Boolean = false
)

data class EventItem(
    val id: String,
    val title: String,
    val date: String,
    val time: String,
    val location: String,
    val coverUrl: String,
    val interestedCount: Int,
    val goingCount: Int,
    val isInterested: Boolean = false,
    val isGoing: Boolean = false,
    val description: String
)

data class NotificationItem(
    val id: String,
    val type: String, // "FRIEND", "LIKE", "COMMENT", "MESSAGE", "SYSTEM", "LIVE"
    val title: String,
    val subtitle: String,
    val timeAgo: String,
    val isRead: Boolean = false,
    val user: User? = null
)

data class AdminStats(
    val totalUsers: Int = 14250,
    val activeUsers: Int = 8920,
    val newUsersToday: Int = 340,
    val totalPosts: Int = 45890,
    val totalComments: Int = 129400,
    val totalReactions: Int = 380200,
    val totalMessages: Int = 67200,
    val totalGroups: Int = 890,
    val totalPages: Int = 1240,
    val totalReels: Int = 15300,
    val totalReports: Int = 14
)
