package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class DataRepository {

    val currentUser = MutableStateFlow(
        User(
            id = "u_me",
            name = "Tanvir Ahmed (তানভীর)",
            username = "tanvir_midia",
            email = "tanvir@netmidia.com",
            phone = "+880 1712-345678",
            avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
            coverUrl = "https://images.unsplash.com/photo-1707343843437-caacff5cfa74?w=1000",
            bio = "Digital Creator & Tech Explorer 🚀 Connecting the world through NET MIDIA!",
            isVerified = true,
            followersCount = 4280,
            followingCount = 310,
            friendsCount = 890,
            isOnline = true,
            role = UserRole.ADMIN
        )
    )

    private val user2 = User(
        id = "u_2",
        name = "Aisha Rahman",
        username = "aisha_art",
        avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300",
        bio = "Artist & Visual Designer 🎨",
        isVerified = true,
        isOnline = true
    )

    private val user3 = User(
        id = "u_3",
        name = "Kazi Rayhan",
        username = "rayhan_vlogs",
        avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300",
        bio = "Traveler & Filmmaker 🎥",
        isVerified = false,
        isOnline = false
    )

    private val user4 = User(
        id = "u_4",
        name = "Nusrat Jahan",
        username = "nusrat_j",
        avatarUrl = "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300",
        bio = "Coffee Lover & Web Dev ☕💻",
        isVerified = true,
        isOnline = true
    )

    private val user5 = User(
        id = "u_5",
        name = "Shakib Al Hasan",
        username = "shakib_sports",
        avatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300",
        bio = "Sports enthusiast and tech writer",
        isVerified = true,
        isOnline = false
    )

    private val _users = MutableStateFlow<List<User>>(listOf(currentUser.value, user2, user3, user4, user5))
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private val _posts = MutableStateFlow<List<Post>>(
        listOf(
            Post(
                id = "p_1",
                author = user2,
                timestamp = "20m ago",
                content = "স্বাগতম NET MIDIA তে! 🌟 আমাদের নতুন সোশ্যাল নেটওয়ার্কিং প্ল্যাটফর্মে যুক্ত হতে পেরে খুব আনন্দিত। সবাই কেমন আছেন?\n\nWelcome to NET MIDIA! Excited to connect with incredible minds around the globe! #NetMidia #Launch",
                mediaUrls = listOf("https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800"),
                feeling = "blessed ✨",
                location = "Dhaka, Bangladesh",
                hashtags = listOf("#NetMidia", "#Launch", "#Community"),
                reactions = mapOf(
                    ReactionType.LIKE to 142,
                    ReactionType.LOVE to 88,
                    ReactionType.WOW to 12
                ),
                userReaction = ReactionType.LOVE,
                comments = listOf(
                    Comment(
                        id = "c_1",
                        author = user3,
                        text = "অনেক শুভকামনা আপু! প্ল্যাটফর্মটি দারুণ লাগছে। 🎉",
                        timestamp = "15m ago",
                        likes = 14,
                        replies = listOf(
                            CommentReply("cr_1", user2, "ধন্যবাদ রায়হান ভাই! ❤️", "10m ago", 5)
                        )
                    ),
                    Comment(
                        id = "c_2",
                        author = user4,
                        text = "Super smooth and modern interface! Loving the dark mode! 🚀",
                        timestamp = "8m ago",
                        likes = 7
                    )
                ),
                shareCount = 29
            ),
            Post(
                id = "p_2",
                author = user4,
                timestamp = "1h ago",
                content = "আজকের সূর্যাস্তের অসাধারণ এক দৃশ্য। কক্সবাজার সমুদ্র সৈকত থেকে তোলা। প্রকৃতি সবসময়ই মনোমুগ্ধকর! 🌅🌊\n\nNature never fails to amaze. Sunset vibes from Cox's Bazar!",
                mediaUrls = listOf(
                    "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800",
                    "https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800"
                ),
                location = "Cox's Bazar Beach",
                feeling = "peaceful 🍃",
                reactions = mapOf(
                    ReactionType.LIKE to 95,
                    ReactionType.LOVE to 120
                ),
                userReaction = null,
                comments = listOf(
                    Comment(
                        id = "c_3",
                        author = currentUser.value,
                        text = "অসাধারণ ছবি! রঙের দারুণ কম্বিনেশন।",
                        timestamp = "45m ago",
                        likes = 3
                    )
                ),
                shareCount = 12
            ),
            Post(
                id = "p_3",
                author = user3,
                timestamp = "3h ago",
                content = "পোল: আপনাদের কাছে নেট মিডিয়ার কোন ফিচারটি সবচেয়ে প্রিয় মনে হচ্ছে?\nPoll: Which feature do you love most in NET MIDIA?",
                poll = PollData(
                    question = "Favorite Feature in NET MIDIA?",
                    options = listOf(
                        PollOption("opt_1", "Short Reels / রিলস", 180, listOf("u_me")),
                        PollOption("opt_2", "Instant Messenger & Calling", 95),
                        PollOption("opt_3", "Stories & Feed Interaction", 72),
                        PollOption("opt_4", "Marketplace & Groups", 43)
                    )
                ),
                reactions = mapOf(
                    ReactionType.LIKE to 65,
                    ReactionType.HAHA to 4
                ),
                userReaction = ReactionType.LIKE,
                shareCount = 8
            )
        )
    )
    val posts: StateFlow<List<Post>> = _posts.asStateFlow()

    private val _stories = MutableStateFlow<List<Story>>(
        listOf(
            Story(
                id = "s_me",
                author = currentUser.value,
                mediaUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
                textContent = "Exploring new ideas! 💡",
                backgroundHex = 0xFF4F46E5,
                createdAt = "Just now",
                viewersCount = 38
            ),
            Story(
                id = "s_1",
                author = user2,
                mediaUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300",
                textContent = "Art studio morning painting 🎨✨",
                backgroundHex = 0xFFEC4899,
                createdAt = "1h ago",
                viewersCount = 85
            ),
            Story(
                id = "s_2",
                author = user3,
                mediaUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300",
                textContent = "Road trip to Sylhet hills 🌄🌲",
                backgroundHex = 0xFF10B981,
                createdAt = "3h ago",
                viewersCount = 120
            ),
            Story(
                id = "s_3",
                author = user4,
                mediaUrl = "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300",
                textContent = "Coffee & Code ☕💻",
                backgroundHex = 0xFFF59E0B,
                createdAt = "5h ago",
                viewersCount = 47
            )
        )
    )
    val stories: StateFlow<List<Story>> = _stories.asStateFlow()

    private val _reels = MutableStateFlow<List<Reel>>(
        listOf(
            Reel(
                id = "r_1",
                creator = user3,
                caption = "Amazing drone shot of Sajek Valley clouds touching the mountains! ☁️🏔️ #TravelBD #Nature #NETMIDIA",
                videoThumbUrl = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800",
                musicTitle = "Original Audio - Rayhan Vlogs (Acoustic Melodies)",
                likesCount = 2450,
                commentsCount = 312,
                sharesCount = 145,
                isLiked = true,
                isFollowing = true
            ),
            Reel(
                id = "r_2",
                creator = user2,
                caption = "Speed acrylic painting: Neon City skyline in 60 seconds! 🎨🖌️ Watch till end!",
                videoThumbUrl = "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800",
                musicTitle = "Cyberpunk Synthwave Beats",
                likesCount = 4890,
                commentsCount = 680,
                sharesCount = 420,
                isLiked = false,
                isFollowing = false
            ),
            Reel(
                id = "r_3",
                creator = user4,
                caption = "5 Life-saving VS Code shortcuts every mobile engineer must know 🚀💻 #CodingTips",
                videoThumbUrl = "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800",
                musicTitle = "Lofi Chill Study Beats",
                likesCount = 1920,
                commentsCount = 145,
                sharesCount = 290,
                isLiked = true,
                isFollowing = true
            )
        )
    )
    val reels: StateFlow<List<Reel>> = _reels.asStateFlow()

    private val _chatThreads = MutableStateFlow<List<ChatThread>>(
        listOf(
            ChatThread(
                id = "t_1",
                participant = user2,
                messages = listOf(
                    ChatMessage("m_1", "u_2", "হ্যালো তানভীর! কেমন আছেন?", timestamp = "10:14 AM"),
                    ChatMessage("m_2", "u_me", "আলহামদুলিল্লাহ ভালো! নতুন প্রজেক্টের কাজ কেমন চলছে?", timestamp = "10:15 AM"),
                    ChatMessage("m_3", "u_2", "দারুণ! গ্রাফিক্স ডিজাইনগুলো তৈরি করেছি। আপনি কি ফ্রি আছেন?", timestamp = "10:16 AM")
                ),
                unreadCount = 1
            ),
            ChatThread(
                id = "t_2",
                participant = user4,
                messages = listOf(
                    ChatMessage("m_4", "u_4", "Did you check the new update on NET MIDIA?", timestamp = "Yesterday"),
                    ChatMessage("m_5", "u_me", "Yes, the UI is super crisp!", timestamp = "Yesterday")
                ),
                unreadCount = 0
            ),
            ChatThread(
                id = "t_3",
                participant = user3,
                messages = listOf(
                    ChatMessage("m_6", "u_3", "সাজেকের নতুন ভিডিওটা আপলোড করেছি রিলসে!", timestamp = "2 days ago")
                ),
                unreadCount = 0
            )
        )
    )
    val chatThreads: StateFlow<List<ChatThread>> = _chatThreads.asStateFlow()

    private val _friendRequests = MutableStateFlow<List<FriendRequest>>(
        listOf(
            FriendRequest("fr_1", user5, 14, "2h ago"),
            FriendRequest(
                "fr_2",
                User(
                    id = "u_6",
                    name = "Mahmudul Hasan",
                    username = "mahmud_tech",
                    avatarUrl = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300"
                ),
                8,
                "5h ago"
            )
        )
    )
    val friendRequests: StateFlow<List<FriendRequest>> = _friendRequests.asStateFlow()

    private val _products = MutableStateFlow<List<ProductItem>>(
        listOf(
            ProductItem(
                id = "prd_1",
                title = "Sony Alpha A7 IV Mirrorless Camera (Brand New)",
                price = 215000.0,
                category = "Electronics",
                location = "Gulshan, Dhaka",
                seller = user3,
                imageUrl = "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800",
                description = "Mint condition Sony A7 IV with 28-70mm lens, 2 original batteries, and box. Used only for 2 indoor shoots."
            ),
            ProductItem(
                id = "prd_2",
                title = "Mechanical Keyboard RGB Custom Gateron Yellow",
                price = 6500.0,
                category = "Computers",
                location = "Dhanmondi, Dhaka",
                seller = user4,
                imageUrl = "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800",
                description = "Hot-swappable 75% layout wireless mechanical keyboard with custom PBT keycaps and lubed switches."
            ),
            ProductItem(
                id = "prd_3",
                title = "Vintage Handcrafted Leather Backpack",
                price = 4200.0,
                category = "Fashion",
                location = "Uttara, Dhaka",
                seller = user2,
                imageUrl = "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800",
                description = "100% genuine full-grain leather backpack suitable for 15-inch laptop and daily commute."
            )
        )
    )
    val products: StateFlow<List<ProductItem>> = _products.asStateFlow()

    private val _groups = MutableStateFlow<List<GroupItem>>(
        listOf(
            GroupItem(
                id = "g_1",
                name = "Developers Hub Bangladesh",
                category = "Technology",
                memberCount = 45200,
                coverUrl = "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800",
                isJoined = true,
                description = "A community for software developers, tech geeks, and problem solvers in Bangladesh.",
                rules = listOf("Be respectful", "No spam or unauthorized ads", "Share knowledge constructively")
            ),
            GroupItem(
                id = "g_2",
                name = "Photography & Filmmakers Club",
                category = "Art & Media",
                memberCount = 28900,
                coverUrl = "https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=800",
                isJoined = false,
                description = "Share your best shots, critique equipment, and arrange photowalks."
            ),
            GroupItem(
                id = "g_3",
                name = "Bangladeshi Travelers Community",
                category = "Travel",
                memberCount = 89400,
                coverUrl = "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800",
                isJoined = true,
                description = "Tips, itineraries, budget travel guides and scenic spots across 64 districts."
            )
        )
    )
    val groups: StateFlow<List<GroupItem>> = _groups.asStateFlow()

    private val _pages = MutableStateFlow<List<PageItem>>(
        listOf(
            PageItem(
                id = "pg_1",
                name = "NET MIDIA Official",
                category = "Internet & Media",
                followersCount = 184500,
                coverUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800",
                avatarUrl = "https://files.catbox.moe/kf0sfa.jpg",
                isFollowing = true,
                isVerified = true,
                about = "Official news, feature updates, and community guidelines for NET MIDIA."
            ),
            PageItem(
                id = "pg_2",
                name = "TechBuzz Daily",
                category = "Science & Tech",
                followersCount = 62000,
                coverUrl = "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800",
                avatarUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300",
                isFollowing = false,
                isVerified = true,
                about = "Your daily dose of tech trends, gadget reviews, and artificial intelligence news."
            )
        )
    )
    val pages: StateFlow<List<PageItem>> = _pages.asStateFlow()

    private val _events = MutableStateFlow<List<EventItem>>(
        listOf(
            EventItem(
                id = "ev_1",
                title = "NET MIDIA Creators Summit 2026",
                date = "Oct 25, 2026",
                time = "10:00 AM - 6:00 PM",
                location = "International Convention City Bashundhara (ICCB), Dhaka",
                coverUrl = "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800",
                interestedCount = 1420,
                goingCount = 580,
                isInterested = true,
                isGoing = true,
                description = "Meet top digital creators, join keynote sessions with industry leaders, and network with passionate influencers."
            ),
            EventItem(
                id = "ev_2",
                title = "Dhaka Tech Expo & Startup Pitch",
                date = "Nov 12, 2026",
                time = "9:00 AM - 8:00 PM",
                location = "Bangabandhu Military Museum Complex",
                coverUrl = "https://images.unsplash.com/photo-1511578314322-379afb476865?w=800",
                interestedCount = 920,
                goingCount = 310,
                isInterested = false,
                isGoing = false,
                description = "Discover high-growth startups, venture capital networking, and innovation workshops."
            )
        )
    )
    val events: StateFlow<List<EventItem>> = _events.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationItem>>(
        listOf(
            NotificationItem(
                id = "n_1",
                type = "REACTION",
                title = "Aisha Rahman reacted ❤️ to your post",
                subtitle = "\"স্বাগতম NET MIDIA তে!...\"",
                timeAgo = "10m ago",
                isRead = false,
                user = user2
            ),
            NotificationItem(
                id = "n_2",
                type = "COMMENT",
                title = "Kazi Rayhan commented on your photo",
                subtitle = "\"অসাধারণ দৃশ্য ভাই!\"",
                timeAgo = "45m ago",
                isRead = false,
                user = user3
            ),
            NotificationItem(
                id = "n_3",
                type = "FRIEND",
                title = "Shakib Al Hasan sent you a friend request",
                subtitle = "14 mutual friends",
                timeAgo = "2h ago",
                isRead = true,
                user = user5
            ),
            NotificationItem(
                id = "n_4",
                type = "SYSTEM",
                title = "Welcome to NET MIDIA!",
                subtitle = "Complete your profile to unlock verified creator rewards.",
                timeAgo = "1d ago",
                isRead = true
            )
        )
    )
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    val adminStats = MutableStateFlow(AdminStats())
    val siteSettings = MutableStateFlow(
        mapOf(
            "appName" to "NET MIDIA",
            "logoUrl" to "https://files.catbox.moe/kf0sfa.jpg",
            "maintenanceMode" to "false",
            "allowSignups" to "true",
            "activeAnnouncement" to "Welcome to the all-new NET MIDIA platform!"
        )
    )

    // Actions
    fun addPost(content: String, mediaUrls: List<String>, feeling: String?, location: String?, poll: PollData?) {
        val newPost = Post(
            id = "p_${UUID.randomUUID()}",
            author = currentUser.value,
            timestamp = "Just now",
            content = content,
            mediaUrls = mediaUrls,
            feeling = feeling,
            location = location,
            poll = poll,
            reactions = emptyMap(),
            userReaction = null,
            comments = emptyList(),
            shareCount = 0
        )
        _posts.update { listOf(newPost) + it }
    }

    fun toggleReaction(postId: String, reactionType: ReactionType) {
        _posts.update { list ->
            list.map { post ->
                if (post.id == postId) {
                    val currentReaction = post.userReaction
                    val newReactions = post.reactions.toMutableMap()

                    if (currentReaction == reactionType) {
                        // Remove reaction
                        newReactions[reactionType] = (newReactions[reactionType] ?: 1) - 1
                        if ((newReactions[reactionType] ?: 0) <= 0) newReactions.remove(reactionType)
                        post.copy(reactions = newReactions, userReaction = null)
                    } else {
                        // Decrease previous reaction if exists
                        if (currentReaction != null) {
                            newReactions[currentReaction] = (newReactions[currentReaction] ?: 1) - 1
                            if ((newReactions[currentReaction] ?: 0) <= 0) newReactions.remove(currentReaction)
                        }
                        // Add new reaction
                        newReactions[reactionType] = (newReactions[reactionType] ?: 0) + 1
                        post.copy(reactions = newReactions, userReaction = reactionType)
                    }
                } else post
            }
        }
    }

    fun addComment(postId: String, text: String) {
        val newComment = Comment(
            id = "c_${UUID.randomUUID()}",
            author = currentUser.value,
            text = text,
            timestamp = "Just now",
            likes = 0
        )
        _posts.update { list ->
            list.map { post ->
                if (post.id == postId) {
                    post.copy(comments = post.comments + newComment)
                } else post
            }
        }
    }

    fun votePoll(postId: String, optionId: String) {
        val currentUserId = currentUser.value.id
        _posts.update { list ->
            list.map { post ->
                if (post.id == postId && post.poll != null) {
                    val updatedOptions = post.poll.options.map { option ->
                        if (option.id == optionId) {
                            if (!option.votedUserIds.contains(currentUserId)) {
                                option.copy(
                                    votes = option.votes + 1,
                                    votedUserIds = option.votedUserIds + currentUserId
                                )
                            } else option
                        } else {
                            if (option.votedUserIds.contains(currentUserId)) {
                                option.copy(
                                    votes = (option.votes - 1).coerceAtLeast(0),
                                    votedUserIds = option.votedUserIds - currentUserId
                                )
                            } else option
                        }
                    }
                    post.copy(poll = post.poll.copy(options = updatedOptions))
                } else post
            }
        }
    }

    fun toggleSavePost(postId: String) {
        _posts.update { list ->
            list.map { if (it.id == postId) it.copy(isSaved = !it.isSaved) else it }
        }
    }

    fun deletePost(postId: String) {
        _posts.update { it.filterNot { p -> p.id == postId } }
    }

    fun addStory(textContent: String?, mediaUrl: String?, backgroundHex: Long) {
        val newStory = Story(
            id = "s_${UUID.randomUUID()}",
            author = currentUser.value,
            mediaUrl = mediaUrl,
            textContent = textContent,
            backgroundHex = backgroundHex,
            createdAt = "Just now",
            viewersCount = 0
        )
        _stories.update { listOf(newStory) + it }
    }

    fun toggleReelLike(reelId: String) {
        _reels.update { list ->
            list.map { reel ->
                if (reel.id == reelId) {
                    val newLiked = !reel.isLiked
                    val newCount = if (newLiked) reel.likesCount + 1 else (reel.likesCount - 1).coerceAtLeast(0)
                    reel.copy(isLiked = newLiked, likesCount = newCount)
                } else reel
            }
        }
    }

    fun toggleReelFollow(reelId: String) {
        _reels.update { list ->
            list.map { if (it.id == reelId) it.copy(isFollowing = !it.isFollowing) else it }
        }
    }

    fun sendMessage(threadId: String, text: String, mediaUrl: String? = null, voiceDurationSec: Int? = null) {
        val newMsg = ChatMessage(
            id = "m_${UUID.randomUUID()}",
            senderId = currentUser.value.id,
            text = text,
            mediaUrl = mediaUrl,
            voiceDurationSec = voiceDurationSec,
            timestamp = "Just now",
            isSeen = true
        )
        _chatThreads.update { threads ->
            threads.map { t ->
                if (t.id == threadId) {
                    t.copy(messages = t.messages + newMsg)
                } else t
            }
        }
    }

    fun acceptFriendRequest(requestId: String) {
        val req = _friendRequests.value.find { it.id == requestId }
        _friendRequests.update { it.filterNot { r -> r.id == requestId } }
        if (req != null) {
            currentUser.update { it.copy(friendsCount = it.friendsCount + 1) }
        }
    }

    fun rejectFriendRequest(requestId: String) {
        _friendRequests.update { it.filterNot { it.id == requestId } }
    }

    fun addProduct(title: String, price: Double, category: String, location: String, description: String, imageUrl: String) {
        val newProduct = ProductItem(
            id = "prd_${UUID.randomUUID()}",
            title = title,
            price = price,
            category = category,
            location = location,
            seller = currentUser.value,
            imageUrl = imageUrl.ifBlank { "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800" },
            description = description
        )
        _products.update { listOf(newProduct) + it }
    }

    fun toggleGroupJoin(groupId: String) {
        _groups.update { list ->
            list.map { g ->
                if (g.id == groupId) {
                    val joined = !g.isJoined
                    val count = if (joined) g.memberCount + 1 else (g.memberCount - 1).coerceAtLeast(0)
                    g.copy(isJoined = joined, memberCount = count)
                } else g
            }
        }
    }

    fun togglePageFollow(pageId: String) {
        _pages.update { list ->
            list.map { p ->
                if (p.id == pageId) {
                    val following = !p.isFollowing
                    val count = if (following) p.followersCount + 1 else (p.followersCount - 1).coerceAtLeast(0)
                    p.copy(isFollowing = following, followersCount = count)
                } else p
            }
        }
    }

    fun toggleEventGoing(eventId: String) {
        _events.update { list ->
            list.map { ev ->
                if (ev.id == eventId) {
                    val going = !ev.isGoing
                    val count = if (going) ev.goingCount + 1 else (ev.goingCount - 1).coerceAtLeast(0)
                    ev.copy(isGoing = going, goingCount = count)
                } else ev
            }
        }
    }

    fun toggleBlockUser(userId: String) {
        _users.update { list ->
            list.map { if (it.id == userId) it.copy(isBlocked = !it.isBlocked) else it }
        }
    }

    fun toggleVerifyUser(userId: String) {
        _users.update { list ->
            list.map { if (it.id == userId) it.copy(isVerified = !it.isVerified) else it }
        }
    }

    fun updateSiteSetting(key: String, value: String) {
        siteSettings.update { it + (key to value) }
    }

    fun updateProfile(name: String, bio: String, phone: String, email: String) {
        currentUser.update {
            it.copy(name = name, bio = bio, phone = phone, email = email)
        }
    }
}
